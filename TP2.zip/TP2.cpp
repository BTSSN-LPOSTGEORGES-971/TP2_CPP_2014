/*
 * TP2.cpp
 *
 *  Created on: 16 oct. 2014
 *      Author: mperouma
 */

#include "Forme.h"

int main(int argc, char** argv)
{
	Forme* carre = new Forme();
	carre->setR(3.0);
	carre->display();
}
